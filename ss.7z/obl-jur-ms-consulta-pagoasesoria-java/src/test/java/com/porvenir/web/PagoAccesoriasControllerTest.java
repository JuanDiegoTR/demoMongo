package com.porvenir.web;

import com.porvenir.domain.dto.ResponseServiceDto;
import com.porvenir.domain.dto.TipoRespuesta;
import com.porvenir.domain.service.PagoAccesoriasService;
import com.porvenir.util.Constants;
import com.porvenir.util.HeadersValidation;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PagoAccesoriasControllerTest {

    @Mock
    private PagoAccesoriasService pagoAccesoriasService;

    @Mock
    private HeadersValidation headersValidation;

    @InjectMocks
    private PagoAccesoriasController pagoAccesoriasController;

    private HttpHeaders headers;

    @BeforeEach
    public void setup() {
        headers = new HttpHeaders();
    }

    @Test
    public void testGetPagoAsesoria_Success() {
        doNothing().when(headersValidation).validateHeaders(any(HttpHeaders.class));

        ResponseEntity<ResponseServiceDto> responseEntity = new ResponseEntity<>(
                new ResponseServiceDto(Constants.CODIGO_200, TipoRespuesta.EXITO, Constants.MENSAJE_200, null),
                HttpStatus.OK);
        when(pagoAccesoriasService.getPagosAccesorias(any(HttpHeaders.class))).thenReturn(responseEntity);

        ResponseEntity<ResponseServiceDto> response = pagoAccesoriasController.getPagoAccesorias(headers);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(Constants.CODIGO_200, response.getBody().getStatusCode());
        assertEquals(TipoRespuesta.EXITO, response.getBody().getType());
        assertEquals(Constants.MENSAJE_200, response.getBody().getStatusDescription());

        verify(headersValidation, times(1)).validateHeaders(any(HttpHeaders.class));
        verify(pagoAccesoriasService, times(1)).getPagosAccesorias(any(HttpHeaders.class));
    }

    @Test
    public void testGetPagoAsesoria_NoDataFound() {
        doNothing().when(headersValidation).validateHeaders(any(HttpHeaders.class));

        ResponseEntity<ResponseServiceDto> responseEntity = new ResponseEntity<>(
                new ResponseServiceDto(Constants.CODIGO_206, TipoRespuesta.ERROR, Constants.MENSAJE_206, null),
                HttpStatus.NOT_FOUND);
        when(pagoAccesoriasService.getPagosAccesorias(any(HttpHeaders.class))).thenReturn(responseEntity);

        ResponseEntity<ResponseServiceDto> response = pagoAccesoriasController.getPagoAccesorias(headers);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals(Constants.CODIGO_206, response.getBody().getStatusCode());
        assertEquals(TipoRespuesta.ERROR, response.getBody().getType());
        assertEquals(Constants.MENSAJE_206, response.getBody().getStatusDescription());

        verify(headersValidation, times(1)).validateHeaders(any(HttpHeaders.class));
        verify(pagoAccesoriasService, times(1)).getPagosAccesorias(any(HttpHeaders.class));
    }

    @Test
    public void testGetPagoAsesoria_TechnicalError() {
        doNothing().when(headersValidation).validateHeaders(any(HttpHeaders.class));

        ResponseEntity<ResponseServiceDto> responseEntity = new ResponseEntity<>(
                new ResponseServiceDto(Constants.CODIGO_500, TipoRespuesta.ERROR, Constants.MENSAJE_500, null),
                HttpStatus.INTERNAL_SERVER_ERROR);
        when(pagoAccesoriasService.getPagosAccesorias(any(HttpHeaders.class))).thenReturn(responseEntity);

        ResponseEntity<ResponseServiceDto> response = pagoAccesoriasController.getPagoAccesorias(headers);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals(Constants.CODIGO_500, response.getBody().getStatusCode());
        assertEquals(TipoRespuesta.ERROR, response.getBody().getType());
        assertEquals(Constants.MENSAJE_500, response.getBody().getStatusDescription());

        verify(headersValidation, times(1)).validateHeaders(any(HttpHeaders.class));
        verify(pagoAccesoriasService, times(1)).getPagosAccesorias(any(HttpHeaders.class));
    }
}
