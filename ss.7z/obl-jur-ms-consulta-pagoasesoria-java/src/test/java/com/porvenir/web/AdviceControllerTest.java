package com.porvenir.web;

import com.porvenir.domain.dto.ResponseServiceDto;
import com.porvenir.exception.ApiException;
import com.porvenir.util.ApiUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;

import java.util.List;

@ExtendWith(MockitoExtension.class)
class AdviceControllerTest {

    @Mock
    ApiUtils apiUtils;

    @InjectMocks
    private AdviceController adviceController;

    @BeforeEach
    void setUp() { MockitoAnnotations.openMocks(this); }

    @Test
    void testHandlerApiException() {

        ResponseEntity<ResponseServiceDto> result = adviceController.handlerApiException(new ApiException("code", HttpStatus.CONTINUE, "message", List.of("String")));
        Assertions.assertNotNull(result);

    }

    @Test
    void testHandlerBindException() {

        BindException bindException = new BindException(new Object(), "Exception");
        bindException.addError(new ObjectError("Error","Message"));
        ResponseEntity<ResponseServiceDto> result = adviceController.handlerBindException(bindException);
        Assertions.assertNotNull(result);

    }

    @Test
    void testHandlerException() {

        ResponseEntity<ResponseServiceDto> result = adviceController.handlerException(new Exception());
        Assertions.assertNotNull(result);

    }
}
