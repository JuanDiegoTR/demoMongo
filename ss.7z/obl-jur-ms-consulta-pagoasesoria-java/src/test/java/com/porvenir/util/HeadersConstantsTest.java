package com.porvenir.util;

import com.porvenir.exception.ApiException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;

import static com.porvenir.util.Constants.*;

@ExtendWith(MockitoExtension.class)
class HeadersConstantsTest {

    HeadersValidation headersValidation = new HeadersValidation();

    @Test
    void testValidateHeaders(){
        HttpHeaders httpHeaders = new HttpHeaders();

        httpHeaders.add(HEADER_SERVICE_X_RQUID,"1234");
        httpHeaders.add(HEADER_SERVICE_X_CHANNEL,"1234");
        httpHeaders.add(HEADER_SERVICE_X_IDENTSERIALNUM,"19332050");
        httpHeaders.add(HEADER_SERVICE_X_GOVISSUEIDENTTYPE,"CC");
        httpHeaders.add(HEADER_SERVICE_X_COMPANYID,"1234");
        httpHeaders.add(HEADER_SERVICE_X_IPADDR,"1234");
        httpHeaders.add(HEADER_SERVICE_X_DEMANDA,"1234");
        httpHeaders.add(HEADER_SERVICE_X_PRETENCION,"1234");
        httpHeaders.add(HEADER_SERVICE_X_TIPO_ID_AFILIADO,"1234");
        httpHeaders.add(HEADER_SERVICE_X_NUMERO_ID_AFILIADO,"1234");

        headersValidation.validateHeaders(httpHeaders);

    }

    @Test
    void testValidateHeadersBad(){

        try{
            HttpHeaders headers = new HttpHeaders();

            headersValidation.validateHeaders(headers);

        }
        catch (ApiException e){
            Assertions.assertNotNull(e);
        }

    }
}
