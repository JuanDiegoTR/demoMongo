package com.porvenir.util;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class ApiUtilsTest {

    public static final String HEADER_SERVICE_X_RQUID = "X-RqUID";
    public static final String HEADER_SERVICE_X_CHANNEL = "X-Channel";
    public static final String HEADER_SERVICE_X_COMPANYID = "X-CompanyId";
    public static final String HEADER_SERVICE_X_IDENTSERIALNUM = "X-IdentSerialNum";
    public static final String HEADER_SERVICE_X_GOVISSUEIDENTTYPE = "X-GovIssueIdentType";
    public static final String HEADER_SERVICE_X_IPADDR = "X-IPAddr";

    @Mock
    private HttpHeaders headers;

    private ApiUtils apiUtils;

    @BeforeEach
    void setUp(){

        MockitoAnnotations.openMocks(this);

        apiUtils = new ApiUtils();

    }

    @Test
    void getHeaderValueExisteHeader(){

        String targetHeader = "X-Test-Header";

        List<String> headerValues = Arrays.asList("Value1", "Value2");

        when(headers.get(targetHeader)).thenReturn(headerValues);

        String result = apiUtils.getHeaderValue(headers, targetHeader);

        assertEquals("Value1", result);

    }


}
