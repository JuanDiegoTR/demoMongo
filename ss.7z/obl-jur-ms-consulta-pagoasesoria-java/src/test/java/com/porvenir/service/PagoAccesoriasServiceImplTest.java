package com.porvenir.service;

import com.porvenir.domain.dto.*;
import com.porvenir.domain.service.impl.PagoAccesoriasServiceImpl;
import com.porvenir.persistence.entities.*;
import com.porvenir.persistence.repository.*;
import com.porvenir.util.ApiUtils;
import com.porvenir.util.Constants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PagoAccesoriasServiceImplTest {

    @Mock
    private ApiUtils apiUtils;

    @Mock
    private AfiliadoVigenciaRepository afiliadoVigenciaRepository;

    @Mock
    private CuentaPorPagarRepository cuentaPorPagarRepository;

    @Mock
    private CumplimientoCxpRepository cumplimientoCxpRepository;

    @InjectMocks
    private PagoAccesoriasServiceImpl pagoAsesoriaService;

    private HttpHeaders headers;

    @BeforeEach
    public void setup() {
        headers = new HttpHeaders();
        headers.add(Constants.HEADER_SERVICE_X_DEMANDA, "1");
        headers.add(Constants.HEADER_SERVICE_X_TIPO_ID_AFILIADO, "tipoId");
        headers.add(Constants.HEADER_SERVICE_X_NUMERO_ID_AFILIADO, "12345");
        headers.add(Constants.HEADER_SERVICE_X_PRETENCION, Constants.PRETENCION_NULIDAD_AFILIACION);
    }

    @Test
    public void testGetPagoAsesoria_WhenEsProcesoDeNulidad_AndAfiliadoVigenciaIsPresent_AndCuentasPorPagarIsEmpty() {
        when(apiUtils.getHeaderValue(any(HttpHeaders.class), eq(Constants.HEADER_SERVICE_X_DEMANDA))).thenReturn("1");
        when(apiUtils.getHeaderValue(any(HttpHeaders.class), eq(Constants.HEADER_SERVICE_X_TIPO_ID_AFILIADO))).thenReturn("tipoId");
        when(apiUtils.getHeaderValue(any(HttpHeaders.class), eq(Constants.HEADER_SERVICE_X_NUMERO_ID_AFILIADO))).thenReturn("12345");
        when(apiUtils.getHeaderValue(any(HttpHeaders.class), eq(Constants.HEADER_SERVICE_X_PRETENCION))).thenReturn(Constants.PRETENCION_NULIDAD_AFILIACION);

        AfiliadoVigenciaEntity afiliadoVigenciaEntity = AfiliadoVigenciaEntity.builder()
                .afiliadoVigenciaId(1L)
                .estadoAfiliadoFondoId("Activo")
                .secuencia(1L)
                .build();
        when(afiliadoVigenciaRepository.findTopByNumeroIdentificacionAndTipoIdentificacionIdOrderBySecuenciaDesc(anyString(), anyString()))
                .thenReturn(afiliadoVigenciaEntity);

        when(cuentaPorPagarRepository.findTipoPagoTotalByIdentificacion(anyString(), anyInt()))
                .thenReturn(Collections.emptyList());

        List<CumplimientoCxpEntity> cumplimientoCxpList = new ArrayList<>();

        ConceptoCondenaEntity conceptoCondenaCostas = ConceptoCondenaEntity.builder().nombreCondena(Constants.CONCEPTO_CONDENA_COSTAS_JUDICIALES).build();
        CumplimientoCxpEntity cumplimientoCxpCostas = CumplimientoCxpEntity.builder().conceptoCondena(conceptoCondenaCostas).valorPago(2000000.0).build();
        cumplimientoCxpList.add(cumplimientoCxpCostas);

        ConceptoCondenaEntity conceptoCondenaIndexacion = ConceptoCondenaEntity.builder().nombreCondena(Constants.CONCEPTO_CONDENA_INDEXACION).build();
        CumplimientoCxpEntity cumplimientoCxpIndexacion = CumplimientoCxpEntity.builder().conceptoCondena(conceptoCondenaIndexacion).valorPago(3000000.0).build();
        cumplimientoCxpList.add(cumplimientoCxpIndexacion);

        ConceptoCondenaEntity conceptoCondenaIntereses = ConceptoCondenaEntity.builder().nombreCondena(Constants.CONCEPTO_CONDENA_INTERESES_MORATORIOS).build();
        CumplimientoCxpEntity cumplimientoCxpIntereses = CumplimientoCxpEntity.builder().conceptoCondena(conceptoCondenaIntereses).valorPago(4000000.0).build();
        cumplimientoCxpList.add(cumplimientoCxpIntereses);

        ConceptoCondenaEntity conceptoCondenaRetroactivo = ConceptoCondenaEntity.builder().nombreCondena(Constants.CONCEPTO_CONDENA_RETROACTIVO_FALLO_CONTRA).build();
        CumplimientoCxpEntity cumplimientoCxpRetroactivo = CumplimientoCxpEntity.builder().conceptoCondena(conceptoCondenaRetroactivo).valorPago(5000000.0).build();
        cumplimientoCxpList.add(cumplimientoCxpRetroactivo);

        when(cumplimientoCxpRepository.findCumplimientoByDemandaIdAndEstadoAndConceptoCondena(anyLong()))
                .thenReturn(cumplimientoCxpList);

        ResponseServiceDto mockedResponse = ResponseServiceDto.builder()
                .statusCode(Constants.CODIGO_206)
                .type(TipoRespuesta.ERROR)
                .statusDescription(Constants.MENSAJE_206)
                .data(null)
                .build();
        when(apiUtils.buildResponseServiceDto(anyString(), any(TipoRespuesta.class), anyString(), any()))
                .thenReturn(mockedResponse);

        ResponseEntity<ResponseServiceDto> response = pagoAsesoriaService.getPagosAccesorias(headers);

        assertEquals(206, response.getStatusCodeValue());
    }

    @Test
    public void testGetPagoAsesoria_WhenEsProcesoDeNulidad_AndAfiliadoVigenciaIsPresent_AndCuentasPorPagarIsNotEmpty() {
        when(apiUtils.getHeaderValue(any(HttpHeaders.class), eq(Constants.HEADER_SERVICE_X_DEMANDA))).thenReturn("1");
        when(apiUtils.getHeaderValue(any(HttpHeaders.class), eq(Constants.HEADER_SERVICE_X_TIPO_ID_AFILIADO))).thenReturn("tipoId");
        when(apiUtils.getHeaderValue(any(HttpHeaders.class), eq(Constants.HEADER_SERVICE_X_NUMERO_ID_AFILIADO))).thenReturn("12345");
        when(apiUtils.getHeaderValue(any(HttpHeaders.class), eq(Constants.HEADER_SERVICE_X_PRETENCION))).thenReturn(Constants.PRETENCION_NULIDAD_AFILIACION);

        AfiliadoVigenciaEntity afiliadoVigenciaEntity = AfiliadoVigenciaEntity.builder()
                .afiliadoVigenciaId(1L)
                .estadoAfiliadoFondoId("Activo")
                .secuencia(1L)
                .build();
        when(afiliadoVigenciaRepository.findTopByNumeroIdentificacionAndTipoIdentificacionIdOrderBySecuenciaDesc(anyString(), anyString()))
                .thenReturn(afiliadoVigenciaEntity);

        List<CuentaPorPagarDto> cuentasPorPagar = new ArrayList<>();

        CuentaPorPagarDto cuentaPorPagarCostas = CuentaPorPagarDto.builder().tipoPago(Constants.TIPO_PAGO_COSTAS_JUDICIALES).valor(1000.0).build();
        cuentasPorPagar.add(cuentaPorPagarCostas);

        CuentaPorPagarDto cuentaPorPagarIndexacion = CuentaPorPagarDto.builder().tipoPago(Constants.TIPO_PAGO_INDEXACION).valor(2000.0).build();
        cuentasPorPagar.add(cuentaPorPagarIndexacion);

        CuentaPorPagarDto cuentaPorPagarMoratorios = CuentaPorPagarDto.builder().tipoPago(Constants.TIPO_PAGO_INTERESES_MORATORIOS).valor(3000.0).build();
        cuentasPorPagar.add(cuentaPorPagarMoratorios);

        CuentaPorPagarDto cuentaPorPagarRetroactivo = CuentaPorPagarDto.builder().tipoPago(Constants.TIPO_PAGO_RETROACTIVO_FALLO_CONTRA).valor(4000.0).build();
        cuentasPorPagar.add(cuentaPorPagarRetroactivo);


        when(cuentaPorPagarRepository.findTipoPagoTotalByIdentificacion(anyString(), anyInt()))
                .thenReturn(cuentasPorPagar);

        ResponseServiceDto mockedResponse = ResponseServiceDto.builder()
                .statusCode(Constants.CODIGO_200)
                .type(TipoRespuesta.EXITO)
                .statusDescription(Constants.MENSAJE_200)
                .data(new PagosDto())
                .build();
        when(apiUtils.buildResponseServiceDto(anyString(), any(TipoRespuesta.class), anyString(), any()))
                .thenReturn(mockedResponse);

        ResponseEntity<ResponseServiceDto> response = pagoAsesoriaService.getPagosAccesorias(headers);

        assertEquals(200, response.getStatusCodeValue());
    }

    @Test
    public void testGetPagoAsesoria_WhenNoEsProcesoDeNulidad() {
        when(apiUtils.getHeaderValue(any(HttpHeaders.class), eq(Constants.HEADER_SERVICE_X_DEMANDA))).thenReturn("1");
        when(apiUtils.getHeaderValue(any(HttpHeaders.class), eq(Constants.HEADER_SERVICE_X_TIPO_ID_AFILIADO))).thenReturn("tipoId");
        when(apiUtils.getHeaderValue(any(HttpHeaders.class), eq(Constants.HEADER_SERVICE_X_NUMERO_ID_AFILIADO))).thenReturn("12345");
        when(apiUtils.getHeaderValue(any(HttpHeaders.class), eq(Constants.HEADER_SERVICE_X_PRETENCION))).thenReturn("");

        List<CumplimientoCxpEntity> cumplimientoCxpList = Collections.emptyList();
        when(cumplimientoCxpRepository.findCumplimientoByDemandaIdAndEstadoAndConceptoCondena(anyLong()))
                .thenReturn(cumplimientoCxpList);

        ResponseServiceDto mockedResponse = ResponseServiceDto.builder()
                .statusCode(Constants.CODIGO_200)
                .type(TipoRespuesta.EXITO)
                .statusDescription(Constants.MENSAJE_200)
                .data(new PagosDto())
                .build();
        when(apiUtils.buildResponseServiceDto(anyString(), any(TipoRespuesta.class), anyString(), any()))
                .thenReturn(mockedResponse);

        ResponseEntity<ResponseServiceDto> response = pagoAsesoriaService.getPagosAccesorias(headers);

        assertEquals(200, response.getStatusCodeValue());
    }
}
