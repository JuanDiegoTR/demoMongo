package com.porvenir.persistence.repository;

import com.porvenir.persistence.entities.CumplimientoCxpEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CumplimientoCxpRepository extends JpaRepository<CumplimientoCxpEntity, Long> {

    @Query(value = "SELECT jcum.* " +
            "FROM MJURIDICAS.JUR_CUMPLIMIENTO_CXP jcum " +
            "JOIN MJURIDICAS.JUR_CONCEPTO_CONDENA jcc ON jcum.CONCEPTO_ID = jcc.CONCEPTO_CONDENA_ID " +
            "WHERE jcum.ESTADO = 'APLICADO' " +
            "AND jcum.DEMANDA_ID = :demandaId " +
            "AND jcc.NOMBRE_CONDENA IN ('Costas','Intereses moratorios','Indexacion','Retroactivo')",
            nativeQuery = true)
    List<CumplimientoCxpEntity> findCumplimientoByDemandaIdAndEstadoAndConceptoCondena(
            @Param("demandaId") Long demandaId);
}
