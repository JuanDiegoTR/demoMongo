package com.porvenir.persistence.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "JUR_CONCEPTO_CONDENA", schema = "MJURIDICAS")
public class ConceptoCondenaEntity {

    @Id
    @Column(name = "CONCEPTO_CONDENA_ID", nullable = false)
    private Long conceptoCondenaId;

    @Column(name = "NOMBRE_CONDENA", length = 100, nullable = false)
    private String nombreCondena;

    @Column(name = "ESTADO_CONDENA", length = 50, nullable = false)
    private String estadoCondena;
}
