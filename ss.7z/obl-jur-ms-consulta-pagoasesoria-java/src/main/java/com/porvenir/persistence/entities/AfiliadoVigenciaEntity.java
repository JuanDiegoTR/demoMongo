package com.porvenir.persistence.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "CTA_AFILIADO_VIGENCIA", schema = "MCUENTAS")
public class AfiliadoVigenciaEntity {

    @Id
    @Column(name = "AFILIADO_VIGENCIA_ID", nullable = false)
    private Long afiliadoVigenciaId;

    @Column(name = "ESTADO_AFILIADO_FONDO_ID", length = 20)
    private String estadoAfiliadoFondoId;

    @Column(name = "SECUENCIA", nullable = false)
    private Long secuencia;
}
