package com.porvenir.persistence.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "SPG_CUENTA_POR_PAGAR", schema = "MPENGES")
public class CuentaPorPagarEntity {

    @Id
    @Column(name = "CUENTA_POR_PAGAR_ID", nullable = false)
    private Long cuentaPorPagarId;

    @Column(name = "TIPO_PAGO_ID", length = 30)
    private String tipoPagoId;

    @Column(name = "VALOR_PESOS")
    private Long valorPesos;
}
