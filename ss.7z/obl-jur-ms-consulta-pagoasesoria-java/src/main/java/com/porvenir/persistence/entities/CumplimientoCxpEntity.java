package com.porvenir.persistence.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "JUR_CUMPLIMIENTO_CXP", schema = "MJURIDICAS")
public class CumplimientoCxpEntity {

    @Id
    @Column(name = "CUMPLIMIENTO_CXP_ID", nullable = false)
    private Long cumplimientoCxpId;

    @Column(name = "DEMANDA_ID", nullable = false)
    private Long demandaId;

    @Column(name = "ESTADO", length = 20, nullable = false)
    private String estado;

    @Column(name = "VALOR_PAGO", nullable = false)
    private Double valorPago;

    @ManyToOne
    @JoinColumn(name = "CONCEPTO_ID", nullable = false)
    private ConceptoCondenaEntity conceptoCondena;
}
