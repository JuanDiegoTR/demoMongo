package com.porvenir.persistence.repository;

import com.porvenir.domain.dto.CuentaPorPagarDto;
import com.porvenir.persistence.entities.CuentaPorPagarEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CuentaPorPagarRepository extends JpaRepository<CuentaPorPagarEntity, Long> {

    @Query(value = "SELECT new com.porvenir.persistence.dto.TipoPagoTotalDto(" +
            "CXP.TIPO_PAGO_ID AS TIPO_PAGO, " +
            "SUM(CXP.VALOR_PESOS)) AS VALOR " +
            "FROM MPENGES.SPG_CUENTA_POR_PAGAR CXP " +
            "JOIN MPENGES.SPG_SOLICITUD SOL ON CXP.SOLICITUD_ID = SOL.SOLICITUD_ID " +
            "JOIN MCUENTAS.CTA_CUENTA CTA ON SOL.CUENTA_AFILIADO = CTA.CUENTA_ID " +
            "JOIN MCUENTAS.CTA_AFILIADO AF ON CTA.AFILIADO_FONDO_ID = AF.AFILIADO_FONDO_ID " +
            "LEFT JOIN MPENGES.SPG_BENEFICIARIO BEN ON CXP.BENEFICIARIO_ID = BEN.BENEFICIARIO_ID " +
            "WHERE " +
            "CXP.TIPO_PAGO_ID IN ('COSTAS_JUDICIALES','INTERESES_MORATORIOS','INDEXACION','RETROACTIVO_FALLO_CONTRA') " +
            "AND CXP.ESTADO_CXP_ID = 'PAGADA' " +
            "AND AF.TIPO_IDENTIFICACION = :tipoIdentificacion " +
            "AND AF.NUMERO_IDENTIFICACION = :numeroIdentificacion " +
            "GROUP BY " +
            "CXP.TIPO_PAGO_ID, " +
            "AF.TIPO_IDENTIFICACION, " +
            "AF.NUMERO_IDENTIFICACION",
            nativeQuery = true)
    List<CuentaPorPagarDto> findTipoPagoTotalByIdentificacion(
            @Param("tipoIdentificacion") String tipoIdentificacion,
            @Param("numeroIdentificacion") Integer numeroIdentificacion);
}
