package com.porvenir.persistence.repository;

import com.porvenir.persistence.entities.AfiliadoVigenciaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AfiliadoVigenciaRepository extends JpaRepository<AfiliadoVigenciaEntity, Long> {

    @Query(value = "SELECT * FROM MCUENTAS.CTA_AFILIADO_VIGENCIA " +
            "WHERE NUMERO_IDENTIFICACION = :numeroIdentificacion " +
            "AND TIPO_IDENTIFICACION_ID = :tipoIdentificacionId " +
            "ORDER BY SECUENCIA DESC " +
            "FETCH FIRST ROW ONLY", nativeQuery = true)
    AfiliadoVigenciaEntity findTopByNumeroIdentificacionAndTipoIdentificacionIdOrderBySecuenciaDesc(
            @Param("numeroIdentificacion") String numeroIdentificacion,
            @Param("tipoIdentificacionId") String tipoIdentificacionId);
}
