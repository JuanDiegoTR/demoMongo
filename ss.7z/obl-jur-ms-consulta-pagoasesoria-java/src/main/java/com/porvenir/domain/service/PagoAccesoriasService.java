package com.porvenir.domain.service;

import com.porvenir.domain.dto.ResponseServiceDto;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

public interface PagoAccesoriasService {

    ResponseEntity<ResponseServiceDto> getPagosAccesorias(HttpHeaders headers);
}
