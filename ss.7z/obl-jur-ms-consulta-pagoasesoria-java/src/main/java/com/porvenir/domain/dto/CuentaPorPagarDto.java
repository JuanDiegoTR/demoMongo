package com.porvenir.domain.dto;

import lombok.*;

@Builder
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CuentaPorPagarDto {

    private String tipoPago;
    private Double valor;
}
