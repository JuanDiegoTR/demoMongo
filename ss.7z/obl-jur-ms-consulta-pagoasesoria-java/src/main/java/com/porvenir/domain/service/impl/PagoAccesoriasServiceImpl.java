package com.porvenir.domain.service.impl;

import com.porvenir.domain.dto.CuentaPorPagarDto;
import com.porvenir.domain.dto.PagosDto;
import com.porvenir.domain.dto.ResponseServiceDto;
import com.porvenir.domain.dto.TipoRespuesta;
import com.porvenir.domain.service.PagoAccesoriasService;
import com.porvenir.persistence.entities.AfiliadoVigenciaEntity;
import com.porvenir.persistence.entities.CumplimientoCxpEntity;
import com.porvenir.persistence.repository.AfiliadoVigenciaRepository;
import com.porvenir.persistence.repository.CuentaPorPagarRepository;
import com.porvenir.persistence.repository.CumplimientoCxpRepository;
import com.porvenir.util.ApiUtils;
import com.porvenir.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import static com.porvenir.util.Constants.*;

/**
 * Implementación del servicio de pago de accesorias.
 * Proporciona métodos para obtener información de pagos y procesos relacionados con una demanda.
 */
@Service
public class PagoAccesoriasServiceImpl implements PagoAccesoriasService {

    private final ApiUtils apiUtils;
    private final AfiliadoVigenciaRepository afiliadoVigenciaRepository;
    private final CuentaPorPagarRepository cuentaPorPagarRepository;
    private final CumplimientoCxpRepository cumplimientoCxpRepository;

    @Autowired
    public PagoAccesoriasServiceImpl(ApiUtils apiUtils, AfiliadoVigenciaRepository afiliadoVigenciaRepository,
                                     CuentaPorPagarRepository cuentaPorPagarRepository,
                                     CumplimientoCxpRepository cumplimientoCxpRepository) {
        this.apiUtils = apiUtils;
        this.afiliadoVigenciaRepository = afiliadoVigenciaRepository;
        this.cuentaPorPagarRepository = cuentaPorPagarRepository;
        this.cumplimientoCxpRepository = cumplimientoCxpRepository;
    }

    /**
     * Obtiene la información de pago de accesorias para una demanda específica.
     *
     * @param headers Encabezados HTTP de la solicitud.
     * @return ResponseEntity con el DTO de respuesta del servicio.
     */
    @Override
    public ResponseEntity<ResponseServiceDto> getPagosAccesorias(HttpHeaders headers) {

        try {
            Long demandaId = Long.valueOf(apiUtils.getHeaderValue(headers, HEADER_SERVICE_X_DEMANDA));
            String tipoIdAfiliado = apiUtils.getHeaderValue(headers, HEADER_SERVICE_X_TIPO_ID_AFILIADO);
            String numeroIdAfiliado = apiUtils.getHeaderValue(headers, HEADER_SERVICE_X_NUMERO_ID_AFILIADO);
            String pretencion = apiUtils.getHeaderValue(headers, HEADER_SERVICE_X_PRETENCION);

            PagosDto pagos = new PagosDto();

            // Obtener cuentas por pagar y afiliado vigencia si es proceso de nulidad
            if (esProcesoDeNulidad(pretencion)) {
                obtenerAfiliadoVigencia(tipoIdAfiliado, numeroIdAfiliado)
                        .ifPresent(afiliadoVigenciaEntity ->
                                pagos.setNulidadAfiliacion(afiliadoVigenciaEntity.getEstadoAfiliadoFondoId()));

                List<CuentaPorPagarDto> cuentasPorPagar = obtenerCuentasPorPagar(tipoIdAfiliado, numeroIdAfiliado);
                if (cuentasPorPagar.isEmpty()) {
                    List<CumplimientoCxpEntity> cumplimientoCxpList = obtenerCumplimientos(demandaId);
                    mapCumplimientoToPagos(cumplimientoCxpList, pagos);
                } else {
                    mapCuentasPorPagarToPagos(cuentasPorPagar, pagos);
                }
            } else {
                // Si no es proceso de nulidad, solo obtener cumplimientos
                List<CumplimientoCxpEntity> cumplimientoCxpList = obtenerCumplimientos(demandaId);
                mapCumplimientoToPagos(cumplimientoCxpList, pagos);
            }
            if (pagos.isEmpty()) {
                return buildResponseServiceDto(CODIGO_206, TipoRespuesta.ADVERTENCIA, MENSAJE_206, null);
            }
            return buildResponseServiceDto(CODIGO_200, TipoRespuesta.EXITO, MENSAJE_200, pagos);
        } catch (NumberFormatException e) {
            return buildResponseServiceDto(CODIGO_400, TipoRespuesta.ERROR, MENSAJE_400, null);
        } catch (Exception e) {
            return buildResponseServiceDto(CODIGO_500, TipoRespuesta.ERROR, MENSAJE_500, null);
        }
    }

    /**
     * Obtiene las cuentas por pagar para un afiliado específico.
     *
     * @param tipoIdAfiliado  Tipo de identificación del afiliado.
     * @param numeroIdAfiliado Número de identificación del afiliado.
     * @return Lista de DTOs de cuentas por pagar.
     */
    private List<CuentaPorPagarDto> obtenerCuentasPorPagar(String tipoIdAfiliado, String numeroIdAfiliado) {
        return cuentaPorPagarRepository.findTipoPagoTotalByIdentificacion(tipoIdAfiliado, Integer.valueOf(numeroIdAfiliado));
    }

    /**
     * Obtiene la vigencia del afiliado más reciente para un afiliado específico.
     *
     * @param tipoIdAfiliado  Tipo de identificación del afiliado.
     * @param numeroIdAfiliado Número de identificación del afiliado.
     * @return Optional con la entidad de vigencia del afiliado.
     */
    private Optional<AfiliadoVigenciaEntity> obtenerAfiliadoVigencia(String tipoIdAfiliado, String numeroIdAfiliado) {
        return Optional.ofNullable(afiliadoVigenciaRepository
                .findTopByNumeroIdentificacionAndTipoIdentificacionIdOrderBySecuenciaDesc(numeroIdAfiliado, tipoIdAfiliado));
    }

    /**
     * Obtiene la lista de cumplimiento de cuentas por pagar para una demanda específica.
     *
     * @param demandaID ID de la demanda.
     * @return Lista de entidades de cumplimiento de cuentas por pagar.
     */
    private List<CumplimientoCxpEntity> obtenerCumplimientos(Long demandaID) {
        return cumplimientoCxpRepository.findCumplimientoByDemandaIdAndEstadoAndConceptoCondena(demandaID);
    }

    /**
     * Mapea las entidades de cumplimiento de cuentas por pagar a un objeto PagosDto.
     *
     * @param cumplimientoCxpList Lista de entidades de cumplimiento.
     * @param pagos               DTO de pagos.
     */
    private void mapCumplimientoToPagos(List<CumplimientoCxpEntity> cumplimientoCxpList, PagosDto pagos) {
        for (CumplimientoCxpEntity cumplimiento : cumplimientoCxpList) {
            String nombreCondena = cumplimiento.getConceptoCondena().getNombreCondena();
            switch (nombreCondena) {
                case Constants.CONCEPTO_CONDENA_COSTAS_JUDICIALES:
                    pagos.setCostosJudiciales(cumplimiento.getValorPago());
                    break;
                case Constants.CONCEPTO_CONDENA_INTERESES_MORATORIOS:
                    pagos.setInteresPorMora(cumplimiento.getValorPago());
                    break;
                case Constants.CONCEPTO_CONDENA_INDEXACION:
                    pagos.setIndexacion(cumplimiento.getValorPago());
                    break;
                case Constants.CONCEPTO_CONDENA_RETROACTIVO_FALLO_CONTRA:
                    pagos.setRetroactivos(cumplimiento.getValorPago());
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * Mapea los DTOs de cuentas por pagar a un objeto PagosDto.
     *
     * @param cuentasPorPagar Lista de DTOs de cuentas por pagar.
     * @param pagos           DTO de pagos.
     */
    private void mapCuentasPorPagarToPagos(List<CuentaPorPagarDto> cuentasPorPagar, PagosDto pagos) {
        for (CuentaPorPagarDto cuenta : cuentasPorPagar) {
            switch (cuenta.getTipoPago()) {
                case Constants.TIPO_PAGO_COSTAS_JUDICIALES:
                    pagos.setCostosJudiciales(cuenta.getValor());
                    break;
                case Constants.TIPO_PAGO_INTERESES_MORATORIOS:
                    pagos.setInteresPorMora(cuenta.getValor());
                    break;
                case Constants.TIPO_PAGO_INDEXACION:
                    pagos.setIndexacion(cuenta.getValor());
                    break;
                case Constants.TIPO_PAGO_RETROACTIVO_FALLO_CONTRA:
                    pagos.setRetroactivos(cuenta.getValor());
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * Verifica si una pretensión es un proceso de nulidad.
     *
     * @param pretencion La pretensión a verificar.
     * @return true si la pretensión es un proceso de nulidad
     */
    private boolean esProcesoDeNulidad(String pretencion) {
        return Constants.PROCESOS_NULIDAD.contains(pretencion);
    }

    /**
     * Build Response Service Dto
     *
     * @param codigoRespuesta codigo respuesta
     * @param tipoRespuesta   tipo de respuesta
     * @param mensaje         mensaje peticion
     * @param pagosDto       data adicional
     * @return Response Entity
     */
    public ResponseEntity<ResponseServiceDto> buildResponseServiceDto(String codigoRespuesta, TipoRespuesta tipoRespuesta, String mensaje, PagosDto pagosDto) {
        ResponseServiceDto responseServiceDto = apiUtils.buildResponseServiceDto(codigoRespuesta,
                tipoRespuesta,
                mensaje,
                pagosDto);
        return ResponseEntity.status(Integer.parseInt(responseServiceDto.getStatusCode())).body(responseServiceDto);
    }
}
