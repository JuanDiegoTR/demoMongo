package com.porvenir.domain.dto;

/**
 * Enumeracion Tipo Respuesta peticion
 */
public enum TipoRespuesta {

    EXITO,
    ERROR,
    ADVERTENCIA

}
