package com.porvenir.domain.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

@Builder
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class PagosDto {

    private Double costosJudiciales;
    private Double indexacion;
    private Double interesPorMora;
    private Double retroactivos;
    private String nulidadAfiliacion;

    /**
     * Verifica si todos los campos del DTO están vacíos o nulos.
     *
     * @return true si todos los campos están vacíos o nulos, de lo contrario false.
     */
    @JsonIgnore
    public boolean isEmpty() {
        return (costosJudiciales == null || costosJudiciales.equals(0.0)) &&
                (indexacion == null || indexacion.equals(0.0)) &&
                (interesPorMora == null || interesPorMora.equals(0.0)) &&
                (retroactivos == null || retroactivos.equals(0.0)) &&
                (nulidadAfiliacion == null || nulidadAfiliacion.isEmpty());
    }
}
