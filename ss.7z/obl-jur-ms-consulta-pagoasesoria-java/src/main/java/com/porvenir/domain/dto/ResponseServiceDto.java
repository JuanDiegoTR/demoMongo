package com.porvenir.domain.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

/**
 * Modelo Response Service Dto
 */
@NoArgsConstructor
@Setter
@Getter
@Builder
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "statusCode",
        "type",
        "statusDescription",
        "data"
})
public class ResponseServiceDto {

    @Schema(description = "Codigo respuesta",example = "200")
    @JsonProperty("statusCode")
    private String statusCode;

    @Schema(description = "Tipo Respuesta",example = "EXITO")
    @JsonProperty("type")
    private TipoRespuesta type;

    @Schema(description = "Mensaje Respuesta",example = "Se realiza busqueda de informacion de solicitud")
    @JsonProperty("statusDescription")
    private String statusDescription;

    @Schema(description = "Data", example = "[Registrado]")
    @JsonProperty("data")
    private Object data;

}
