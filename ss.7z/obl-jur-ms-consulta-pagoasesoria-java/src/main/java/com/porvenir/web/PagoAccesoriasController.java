package com.porvenir.web;

import com.porvenir.domain.dto.ResponseServiceDto;
import com.porvenir.domain.service.PagoAccesoriasService;
import com.porvenir.util.HeadersValidation;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping
@Tag(name = "Demanda juridica - pagos accesorias")
public class PagoAccesoriasController {

    private final PagoAccesoriasService pagoAccesoriasService;
    private final HeadersValidation headersValidation;

    /**
     * Constructor para inyectar el servicio de pago de asesoría.
     *
     * @param pagoAccesoriasService Servicio de pago de asesoría.
     */
    @Autowired
    public PagoAccesoriasController(PagoAccesoriasService pagoAccesoriasService,
                                    HeadersValidation headersValidation) {
        this.pagoAccesoriasService = pagoAccesoriasService;
        this.headersValidation = headersValidation;
    }

    /**
     * Endpoint GET para obtener la información de pago de asesoría.
     *
     * @param headers Encabezados HTTP de la solicitud.
     * @return ResponseEntity con el DTO de respuesta del servicio.
     */
    @Operation(summary = "Buscar los pagos por un afiliado específico o su demanda ID")
    @Parameters(value ={
            @Parameter(in = ParameterIn.HEADER, name = "X-RqUID",               schema = @Schema(type = "string"),
                    description = "header X-RqUID Id de request para efectos de traza y correlacion de transacciones"),
            @Parameter(in = ParameterIn.HEADER, name = "X-Channel",             schema = @Schema(type = "string"),
                    description = "header X-Channel canal desde donde se consume el servicio"),
            @Parameter(in = ParameterIn.HEADER, name = "X-IdentSerialNum",      schema = @Schema(type = "string"),
                    description = "header X-IdentSerialNum numero identificacion del afiliado para efectos de traza"),
            @Parameter(in = ParameterIn.HEADER, name = "X-GovIssueIdentType",   schema = @Schema(type = "string"),
                    description = "header X-GovIssueIdentType tipo de identificacion del afiliado para efectos de traza"),
            @Parameter(in = ParameterIn.HEADER, name = "X-IPAddr",              schema = @Schema(type = "string"),
                    description = "header X-IPAddr Ip desde donde se consume el servicio para efecto de trazas"),
            @Parameter(in = ParameterIn.HEADER, name = "X-CompanyId",           schema = @Schema(type = "string"),
                    description = "header X-CompanyId Nombre o identificador de la compañia que realiza el consumo del servicio"),
            @Parameter(in = ParameterIn.HEADER, name = "X-DemandaId",           schema = @Schema(type = "long"),
                    description = "ID de la demanda jurídica"),
            @Parameter(in = ParameterIn.HEADER, name = "X-TipoIdAfiliado",      schema = @Schema(type = "string"),
                    description = "Tipo documento del afiliado"),
            @Parameter(in = ParameterIn.HEADER, name = "X-NumeroIdAfiliado",    schema = @Schema(type = "string"),
                    description = "Numero documento del afiliado"),
            @Parameter(in = ParameterIn.HEADER, name = "X-Pretension",          schema = @Schema(type = "string"),
                    description = "Pretension de la demanda"),
    })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(examples = {
                            @ExampleObject(name = "Información de la solicitud de transferencia",
                                    summary = "Se encuentra información del proceso en la bd",
                                    value = """
                                    {
                                        "statusCode": "200",
                                        "type": "EXITO",
                                        "statusDescription": "Información de un proceso ejecutivo encontrada en Base de Datos",
                                        "data": {
                                            "costosJudiciales": "1100000",
                                            "indexacion": "9000000",
                                            "interesPorMora": "12538454",
                                            "retroactivos": "6978890",
                                            "nulidadAfiliacion": "PRETENCIÓN DEFINIDA"
                                        }
                                    }
                                    """
                            )
                    }, schema = @Schema(implementation = ResponseServiceDto.class), mediaType = "application/json")
            }, description = "Demanda procesada exitosamente"),
            @ApiResponse(responseCode = "206", content = {
                    @Content(examples = {
                            @ExampleObject(name = "No existe demanda",
                                    summary = "No se encontro el dato",
                                    value = "{\n" +
                                            "    \"statusCode\": \"206\",\n" +
                                            "    \"type\": \"ADVERTENCIA\",\n" +
                                            "    \"statusDescription\": \"No se encontró información de pagos con los datos ingresados\"\n" +
                                            "}")
                    }, schema = @Schema(implementation = ResponseServiceDto.class), mediaType = "application/json")
            }, description = "Datos no encontrados"),
            @ApiResponse(responseCode = "400", content = {
                    @Content(examples = {
                            @ExampleObject(name = "Parametros de envio",
                                    summary = "Falto envio de Header",
                                    value = "{\n" +
                                            "    \"statusCode\": \"400\",\n" +
                                            "    \"type\": \"ERROR\",\n" +
                                            "    \"statusDescription\": \"Parametros de busqueda no validos\"\n" +
                                            "}")
                    },schema = @Schema(implementation = ResponseServiceDto.class),mediaType = "application/json")
            },description = "Parámetros Inválidos"),
            @ApiResponse(responseCode = "500", content = {
                    @Content(examples = {
                            @ExampleObject(name = "Comunicacion con bd",
                                    summary = "No se pudo conectar con la bd",
                                    value = "{\n" +
                                            "    \"statusCode\": \"500\",\n" +
                                            "    \"type\": \"ERROR\",\n" +
                                            "    \"statusDescription\": \"Error Interno del Servidor\"\n" +
                                            "}")
                    }, schema = @Schema(implementation = ResponseServiceDto.class), mediaType = "application/json")
            }, description = "Error Técnico")
    })
    @GetMapping(value ="/datosPagoAccesorias", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseServiceDto> getPagoAccesorias(@RequestHeader HttpHeaders headers) {
        headersValidation.validateHeaders(headers);
        return pagoAccesoriasService.getPagosAccesorias(headers);
    }
}
