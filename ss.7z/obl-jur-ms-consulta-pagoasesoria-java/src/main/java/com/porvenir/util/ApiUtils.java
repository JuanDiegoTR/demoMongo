package com.porvenir.util;

import com.porvenir.domain.dto.ResponseServiceDto;
import com.porvenir.domain.dto.TipoRespuesta;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class ApiUtils {

    /**
     * Obtener valor del header especifico
     *
     * @param headers      HttpHeaders de los headers
     * @param targetHeader header a evaluar
     * @return String con el valor del header, vacio si no encontro el header
     */
    public String getHeaderValue(HttpHeaders headers, String targetHeader) {
        List<String> listHeader = headers.get(targetHeader);
        if (listHeader != null) {
            return listHeader.get(0);
        } else {
            return "";
        }
    }

    /**
     * Construir Respuesta Servicio
     *
     * @param statusCode  el codigo de respuesta
     * @param type    el tipo de respuesta
     * @param statusDescription el mensaje de respuesta
     * @param data             informacion adicional de la respuesta
     * @return ResponseServiceDto con la informacion de respuesta
     */
    public ResponseServiceDto buildResponseServiceDto(String statusCode,
                                                      TipoRespuesta type,
                                                      String statusDescription,
                                                      Object data) {
        return ResponseServiceDto.builder()
                .statusCode(statusCode)
                .type(type)
                .statusDescription(statusDescription)
                .data(data)
                .build();
    }

}
