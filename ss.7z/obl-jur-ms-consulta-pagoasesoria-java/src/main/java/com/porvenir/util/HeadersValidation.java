package com.porvenir.util;

import com.porvenir.exception.ApiException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

import static com.porvenir.util.Constants.*;

@Component
public class HeadersValidation {

    /**
     * Validación de header
     * @param headers    los headers
     */
    public void validateHeaders(HttpHeaders headers) {
        validateExistsHeader(headers,HEADER_SERVICE_X_RQUID);
        validateExistsHeader(headers,HEADER_SERVICE_X_CHANNEL);
        validateExistsHeader(headers,HEADER_SERVICE_X_IDENTSERIALNUM);
        validateExistsHeader(headers,HEADER_SERVICE_X_GOVISSUEIDENTTYPE);
        validateExistsHeader(headers,HEADER_SERVICE_X_COMPANYID);
        validateExistsHeader(headers,HEADER_SERVICE_X_IPADDR);

        validateExistsHeader(headers,HEADER_SERVICE_X_DEMANDA);
        validateExistsHeader(headers,HEADER_SERVICE_X_TIPO_ID_AFILIADO);
        validateExistsHeader(headers,HEADER_SERVICE_X_NUMERO_ID_AFILIADO);
    }

    /**
     * Validar si existe el header en los headers de la peticion
     * @param headers    los headers
     * @param nameHeader el nombre del header a validar
     */
    private void validateExistsHeader(HttpHeaders headers,String nameHeader){
        if (!headers.containsKey(nameHeader) || headers.get(nameHeader)==null || Objects.requireNonNull(headers.get(nameHeader)).get(0).isEmpty()){
            throw new ApiException("400", HttpStatus.BAD_REQUEST, "El header " + nameHeader + " es obligatorio.", List.of());
        }
    }

}
