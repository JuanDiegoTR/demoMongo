package com.porvenir.util;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.Set;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Constants {

    /**
     * Headers
     */
    public static final String HEADER_SERVICE_X_RQUID = "X-RqUID";
    public static final String HEADER_SERVICE_X_CHANNEL = "X-Channel";
    public static final String HEADER_SERVICE_X_COMPANYID = "X-CompanyId";
    public static final String HEADER_SERVICE_X_IDENTSERIALNUM = "X-IdentSerialNum";
    public static final String HEADER_SERVICE_X_GOVISSUEIDENTTYPE = "X-GovIssueIdentType";
    public static final String HEADER_SERVICE_X_IPADDR = "X-IPAddr";
    //Parametros de consulta
    public static final String HEADER_SERVICE_X_DEMANDA = "X-DemandaId";
    public static final String HEADER_SERVICE_X_TIPO_ID_AFILIADO = "X-TipoIdAfiliado";
    public static final String HEADER_SERVICE_X_NUMERO_ID_AFILIADO = "X-NumeroIdAfiliado";
    public static final String HEADER_SERVICE_X_PRETENCION = "X-Pretension";

    /**
     * Mensaje y codigo de respuesta
     */
    public static final String CODIGO_206 = "206";
    public static final String MENSAJE_206 = "No se encontró información de pagos con los datos ingresadoss";
    public static final String CODIGO_200 = "200";
    public static final String MENSAJE_200 = "Información de pagos encontrada en Base de Datos ";
    public static final String CODIGO_400 = "400";
    public static final String MENSAJE_400 = "Parametros de busqueda no validos";
    public static final String CODIGO_500 = "500";
    public static final String MENSAJE_500 = "Error Interno del Servidor";

    /**
     * Tipo pagos cuentas por gapar
     */
    public static final String TIPO_PAGO_COSTAS_JUDICIALES = "COSTAS_JUDICIALES";
    public static final String TIPO_PAGO_INTERESES_MORATORIOS = "INTERESES_MORATORIOS";
    public static final String TIPO_PAGO_INDEXACION = "INDEXACION";
    public static final String TIPO_PAGO_RETROACTIVO_FALLO_CONTRA = "EMBARGADO";

    /**
     * Tipo pagos concepto demanda
     */
    public static final String CONCEPTO_CONDENA_COSTAS_JUDICIALES = "Costas";
    public static final String CONCEPTO_CONDENA_INTERESES_MORATORIOS = "Intereses moratorios";
    public static final String CONCEPTO_CONDENA_INDEXACION = "Indexacion";
    public static final String CONCEPTO_CONDENA_RETROACTIVO_FALLO_CONTRA = "Retroactivo";

    /**
     * Tipos de nulidades
     */
    public static final String PRETENCION_NULIDAD_AFILIACION = "NULIDAD DE LA AFILIACION";
    public static final String PRETENCION_NULIDAD_PERJUICIOS_PENSIONADO = "NULIDAD PERJUICIOS PENSIONADO";
    public static final String PRETENCION_NULIDAD_PERJUICIOS_NO_PENSIONADO = "NULIDAD PERJUICIOS NO PENSIONADO";
    public static final String PRETENCION_TRASLADO_REGIMEN = "TRASLADO DE REGIMEN";
    public static final String PRETENCION_PENSION_VEJEZ = "PENSION DE VEJEZ";


    /**
     * Lista de nulidades
     */
    public static final Set<String> PROCESOS_NULIDAD = Set.of(
            Constants.PRETENCION_NULIDAD_AFILIACION,
            Constants.PRETENCION_NULIDAD_PERJUICIOS_PENSIONADO,
            Constants.PRETENCION_NULIDAD_PERJUICIOS_NO_PENSIONADO,
            Constants.PRETENCION_TRASLADO_REGIMEN,
            Constants.PRETENCION_PENSION_VEJEZ
    );
}
